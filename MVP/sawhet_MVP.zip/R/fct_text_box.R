#' Get text box
#'
#' @description Get the appropriate text box, either plain or MCE
#'
#' @return A text box for the UI.
#'
#' @noRd
get_text_box <- function(id, mce_text) {
  if(mce_text) {
    tinyMCE(
      inputId = id, 
      content = "", 
      options = 'plugins: ["lists charmap"],
      toolbar: "bold italic | bullist numlist"'
    )
  } else (
    textAreaInput(inputId = id, label = NULL)
  )
}

#' HTML to ASCII
#'
#' @description Remove HTML tags from text and convert to ASCII characters
#'
#' @return Plain text without HTML tags
#'
#' @noRd
html_to_ascii <- function(text) {
  text |> 
    get_html_text() |> 
    convert_to_ascii()
}

#' Clean text
#'
#' @description Replace unicode characters and line breaks
#'
#' @return Plain text without special characters
#'
#' @noRd
clean_text <- function(text) {
  text |> 
    replace_unicode_characters() |> 
    replace_line_breaks()
}

#' Get HTML text
#'
#' @description Gets the text component of HTML, removing the HTML tags and other characters
#'
#' @return Plain text (ASCII) with HTML tags replaced
#'
#' @noRd
get_html_text <- function(text) {
  if(text == "") {
    return("")
  }
  
  text |>
    charToRaw() |>
    read_html() |>
    html_text()
}

#' Converts text from UTF-8 to ASCII and replaces special characters
#'
#' @description Replaces special characters with Unicode (<U+...>)
#'
#' @return Plain text (ASCII) with Unicode for special characters
#'
#' @noRd
convert_to_ascii <- function(text) {
  text |> 
    iconv(from = "UTF-8", "ASCII", sub = "Unicode")
}

#' Replace Unicode character patterns
#'
#' @description Replaces Unicode special characters in ASCII plain text with another character(s)
#'
#' @return Plain text (ASCII) with Unicode special characters replaced
#'
#' @noRd
replace_unicode_characters <- function(text, replacement = "_") {
  # remove non-breaking spaces first so they aren't replaced by a non-whitespace character
  text_nbsp <- gsub("<U\\+00A0>", " ", text)
  gsub("<U\\+.+?>", replacement, text_nbsp)
}

#' Replace line breaks
#'
#' @description Removes line breaks from text. Useful for counting characters.
#'
#' @return Plain text (ASCII) with line breaks replaced
#'
#' @noRd
replace_line_breaks <- function(text, replacement = " ") {
  gsub("[\r\n]", replacement, text)
}

#' Check words
#'
#' @description Check the number of words against a min and max.
#'
#' @return A function to check the number of words.
#'
#' @noRd
check_words <- function(min_words = 0, max_words = Inf) {
  function(text) {
    stri_count(text, regex = "\\S+") |> 
      check_length(min_words, max_words, "word")
  }
}

#' Check characters
#'
#' @description Check the number of characters against a min and max.
#'
#' @return A function to check the number of characters
#'
#' @noRd
check_characters <- function(min_chars = 0, max_chars = Inf) {
  function(text) {
    stri_count(text, regex = "\\S") |> 
      check_length(min_chars, max_chars, "character")
  }
}

#' Check citations
#'
#' @description Check the number of citations against a min and max.
#'
#' @return A function to check the number of citations
#'
#' @noRd
check_citations <- function(min_citations = 0, max_citations = Inf) {
  function(text) {
    stri_count(text, regex = "\\(.+, \\d{4}\\)") |> 
      check_length(min_citations, max_citations, "citation")
  }
}

#' Perform multiple validation checks
#'
#' @description Perform multiple validation checks
#'
#' @return A function to perform multiple validation checks
#'
#' @noRd
check_multiple <- function(...) {
  function(text) {
    sapply(list(...), do.call, list(text)) |> 
      paste(collapse = "")
  }
}

#' Check length
#'
#' @description Check a number against a min and max.
#'
#' @return A string of the check results, either too short, too long, or just right.
#'
#' @noRd
check_length <- function(text_length, min_length, max_length, check_text) {
  check_text_plural <- paste0(check_text, "s")
  
  check_text_actual <- ifelse(
    text_length == 1, check_text, check_text_plural
  )
  
  check_text_min <- ifelse(
    min_length == 1, check_text, check_text_plural
  )
  
  check_text_max <- ifelse(
    max_length == 1, check_text, check_text_plural
  )
  
  if(text_length < min_length) {
    sprintf(
      "Text is too short. At least %d %s expected, %d %s found.", 
      min_length, check_text_min, text_length, check_text_actual
    ) |> 
      format_valid_fail()
  } else if(text_length > max_length) {
    sprintf(
      "Text is too long. At most %d %s expected, %d %s found.", 
      max_length, check_text_max, text_length, check_text_actual
    ) |> 
      format_valid_fail()
  } else {
    sprintf("Text meets required validation checks for %s.", check_text_plural) |> 
      format_valid_pass()
  }
}

#' Format validation failure
#'
#' @description Format a validation failure message.
#'
#' @return A string of an HTML paragraph
#'
#' @noRd
format_valid_fail <- function(text) {
  sprintf(
    "<p style = 'color:red'>%s</p>", text
  )
}

#' Format validation success
#'
#' @description Format a validation success message.
#'
#' @return A string of an HTML paragraph
#'
#' @noRd
format_valid_pass <- function(text) {
  sprintf(
    "<p style = 'color:green'>%s</p>", text
  )
}

