#' download UI Function
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd 
#'
#' @importFrom shiny NS tagList 
mod_download_ui <- function(id){
  ns <- NS(id)
 
  downloadButton(ns("download"))
}
    
#' download Server Functions
#'
#' @noRd 
mod_download_server <- function(id, file_id, metadata, lab_report, figures_tables){
  moduleServer( id, function(input, output, session){
    ns <- session$ns
 
    text_output <-  reactive({
      combine_output(metadata(), lab_report())
    })
    
    output$download <- downloadHandler(
      filename = function() {
        zipfile_name(file_id())
      },
      content = function(con) {
        zip_content(con, file_id(), text_output(), figures_tables())
      }, 
      contentType = "application/zip"
    )
  })
}
    
## To be copied in the UI
# mod_download_ui("download_ui_1")
    
## To be copied in the server
# mod_download_server("download_ui_1")
