
# sawhet

<!-- badges: start -->
[![Lifecycle: experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
<!-- badges: end -->

The goal of sawhet is to ...

## Installation

You can install the released version of sawhet from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("sawhet")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(sawhet)
## basic example code
```

## Code of Conduct

Please note that the sawhet project is released with a [Contributor Code of Conduct](https://contributor-covenant.org/version/2/0/CODE_OF_CONDUCT.html). By contributing to this project, you agree to abide by its terms.
